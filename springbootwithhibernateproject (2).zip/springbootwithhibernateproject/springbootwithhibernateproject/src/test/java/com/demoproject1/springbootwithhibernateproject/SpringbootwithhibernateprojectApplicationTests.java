package com.demoproject1.springbootwithhibernateproject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootwithhibernateprojectApplicationTests {

	@Test
	void contextLoads() {
	}

}
