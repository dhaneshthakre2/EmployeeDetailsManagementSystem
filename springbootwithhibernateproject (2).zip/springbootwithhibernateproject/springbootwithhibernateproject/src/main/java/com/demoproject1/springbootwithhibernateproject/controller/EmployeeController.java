package com.demoproject1.springbootwithhibernateproject.controller;


import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;

import com.demoproject1.springbootwithhibernateproject.entity.Employee;
import com.demoproject1.springbootwithhibernateproject.service.EmployeeService;



@RestController
public class EmployeeController {

	@Autowired
	EmployeeService service;
	
//	@GetMapping("/all")
//	public List<Employee>  getEmployeeRecord() {
//		
//		return service.getEmployeeRecord() ;
//	}
	
	@GetMapping("/all")
	public List<Employee>  getEmployeeRecord() {
		return service.getEmployeeRecord() ;
	}
	
	@PostMapping("/add")
	public String insertEmployee(@RequestBody Employee al){
		 
	System.out.println("coming students = "+al);
		String msg = service.insertEmployee(al);
		return msg;
	}
	
	@GetMapping("/byid/ {id}")
	public List <Employee> getEmployeeByID(@PathVariable int roll) {
		List <Employee> list = service.getEmployeeByID(roll);
		return list;
	}
}
