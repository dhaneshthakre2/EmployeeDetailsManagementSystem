package com.demoproject1.springbootwithhibernateproject.dao;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;

import org.hibernate.Transaction;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Repository;

import com.demoproject1.springbootwithhibernateproject.entity.Employee;

@Repository
public class EmployeeDao {

	@Autowired
	SessionFactory sf; //1st
	
	public List<Employee> getEmployeeRecord() {
		
		Session session = sf.openSession();//2nd
		
		Criteria criteria = session.createCriteria(Employee.class);//4th 
		
		//List<Employee> list = criteria.list(); //5th
		return criteria.list(); //6th
	}

	public String insertEmployee(Employee al) {
		// TODO Auto-generated method stub
		System.out.println("In dao : "+al);
		Session session = sf.openSession();
		
		Transaction tr = session.beginTransaction();
		
			int row = (int)session.save(al);
		tr.commit();
		return "Student saved successfully..!!" ;
	}

	public List <Employee> getEmployeeByID(int roll) {
		// TODO Auto-generated method stub
		Session session = sf.openSession();
		Criteria cr = session.createCriteria(Employee.class);
		
		cr.add(Restrictions.eq("roll", cr));
		List <Employee> list =  cr.list();
		
		return list;
	}

}
