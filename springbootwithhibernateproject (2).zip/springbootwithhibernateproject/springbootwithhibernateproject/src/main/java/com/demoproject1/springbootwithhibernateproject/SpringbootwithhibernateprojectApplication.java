package com.demoproject1.springbootwithhibernateproject;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringbootwithhibernateprojectApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringbootwithhibernateprojectApplication.class, args);
	}

}
