package com.demoproject1.springbootwithhibernateproject.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.demoproject1.springbootwithhibernateproject.dao.EmployeeDao;
import com.demoproject1.springbootwithhibernateproject.entity.Employee;


@Service
public class EmployeeService {

	@Autowired
	EmployeeDao dao;
	
	
	public List<Employee> getEmployeeRecord() {
		
		// TODO Auto-generated method stub
		return dao.getEmployeeRecord();
	}


	public String insertEmployee(Employee al) {
		// TODO Auto-generated method stub
		String msg = dao.insertEmployee(al);
		return msg;
	}


	public List <Employee> getEmployeeByID(int roll) {
		// TODO Auto-generated method stub
		return dao.getEmployeeByID(roll);
	}


}
