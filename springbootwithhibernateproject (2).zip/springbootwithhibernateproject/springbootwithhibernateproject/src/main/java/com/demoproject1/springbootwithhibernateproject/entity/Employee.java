package com.demoproject1.springbootwithhibernateproject.entity;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Employee {

	private int id;
	private String name;
	private String dep;
	private String level;
	
	@Id
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getDep() {
		return dep;
	}
	public void setDep(String dep) {
		this.dep = dep;
	}
	public String getLevel() {
		return level;
	}
	public void setLevel(String level) {
		this.level = level;
	}
	@Override
	public String toString() {
		return "Employee [id=" + id + ", name=" + name + ", dep=" + dep + ", level=" + level + "]";
	}
	
	
}
